package com.example.card_gram;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnDasar, btnCard;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCard = (Button) findViewById(R.id.card);
        btnCard.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String url = "https://drive.google.com/drive/folders/1a-fy-vZdLpe52c2klIDnyvVTQBVpaf-3?usp=sharing";
                Intent web = new Intent(Intent.ACTION_VIEW);
                web.setData(Uri.parse(url));
                startActivity(web);
            }
        }));

    }

    public void pythonA(View view) {
        Intent piton = new Intent(getApplicationContext(), PythonActivity.class);
        startActivity(piton);
    }

    public void javaA(View view) {
        Intent jawa = new Intent(getApplicationContext(), JavaActivity.class);
        startActivity(jawa);
    }

    public void dasarA(View view) {
        Intent dasar = new Intent(getApplicationContext(), DasarActivity.class);
        startActivity(dasar);
    }
}
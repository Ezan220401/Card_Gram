package com.example.card_gram;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class DasarActivity extends AppCompatActivity {
    TextView kuis;
    RadioGroup pilihanABC;
    RadioButton PilihanA, PilihanB, PilihanC;
    int number = 0;
    public static int hasil, benar, salah;

    String[] pertanyaan = new String[]{
            "1, Intruksi yang digunakan untuk melakukan perulangan berdasarkan interval yang ditentukan pengguna adalah?",
            "2, Statement yang digunakan untuk menentukan pilihan dari suatu kondisi yang diberikan adalah?",
            "3, Sekumpulan objek data serupa yang disimpan di lokasi memori berurutan yang di deklarasikan di bawah judul umum atau nama variabel",
            "4, Dalam pemrograman komputer, lokasi penyimpanan dan terkait nama simbolis yang berisi beberapa kuantitas disebut?",
            "5, Tipe data yang cocok untuk satu karakter dari kata yang dimasukkan adalah?",

            "6, Tipe data yang cocok untuk kata dan kalimat adalah?",
            "7, Tipe data berbentuk bilangan bulat atau tipe data numerik yang umum digunakan untuk menyimpan angka tanpa komponen pecahan?",
            "8, Tipe data yang memiliki dua nilai yaitu benar (true) atau salah (false) untuk mewakili kebenaran logika?",
            "9, Tipe data berbentuk bilangan bulat atau tipe data numerik yang umum digunakan untuk menyimpan angka pecahan adalah?",
            "10, Dalam ilmu komputer, koleksi dari rutin-rutin program yang digunakan untuk membangun dan mengembangkan perangkat lunak disimpan dalam?"

    };

    String[] pilihan = new String[]{
            "For", "For dan While", "While",
            "For dan While", "If dan Else", "String dan Char",
            "Array", "Char", "List",
            "Variabel", "Ampul", "Paket",
            "Char", "Boolean", "String",

            "Char", "Boolean", "String",
            "Integer", "Boolean", "Float",
            "Char", "Boolean", "String",
            "Integer", "Boolean", "Float",
            "Library", "Memori","Cloud"


    };

    String[] jawabanBenar = new String[]{
            "For",
            "If dan Else",
            "Array",
            "Variabel",
            "Char",

            "String",
            "Integer",
            "Boolean",
            "Float",
            "Library"

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dasar);

        kuis= (TextView) findViewById(R.id.KuisCoba);
        pilihanABC = (RadioGroup) findViewById(R.id.pilihan);
        PilihanA =(RadioButton) findViewById(R.id.pilihanA);
        PilihanB =(RadioButton) findViewById(R.id.pilihanB);
        PilihanC =(RadioButton) findViewById(R.id.pilihanC);


        kuis.setText(pertanyaan[number]);
        PilihanA.setText(pilihan[0]);
        PilihanB.setText(pilihan[1]);
        PilihanC.setText(pilihan[2]);

        pilihanABC.check(0);
        benar=0;
        salah=0;
    }

    public void next (View v){
        if (PilihanA.isChecked()||PilihanB.isChecked()||PilihanC.isChecked()) {

            RadioButton jawaban_user = (RadioButton) findViewById(pilihanABC.getCheckedRadioButtonId());
            String ambil_jawaban_user = jawaban_user.getText().toString();
            pilihanABC.check(0);
            if (ambil_jawaban_user.equalsIgnoreCase(jawabanBenar[number])) benar++;
            else salah++;
            number++;

            if (number < pertanyaan.length) {
                kuis.setText(pertanyaan[(number)]);
                PilihanA.setText(pilihan[(number * 3) + 0]);
                PilihanB.setText(pilihan[(number * 3) + 1]);
                PilihanC.setText(pilihan[(number * 3) + 2]);

            } else {
                hasil = benar * 10;
                Intent selesai = new Intent(DasarActivity.this, HasilActivity.class);
                startActivity(selesai);
            }
        }
        else{
            Toast.makeText(this, "Jawab Terlebih Dahulu",Toast.LENGTH_LONG).show();

        }
    }
}
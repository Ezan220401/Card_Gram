package com.example.card_gram;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class JavaActivity extends AppCompatActivity {
    TextView kuis;
    RadioGroup pilihan_jv_ABC;
    RadioButton PilihanA, PilihanB, PilihanC;
    int number = 0;
    public static int hasil_jv, benar_jv, salah_jv;

    String[] pertanyaan_jv = new String[]{
            "Soal Pertama:"
                    + "\n" + "public class Main {\n" +
                    "  public static void main(String[] args) {\n" +
                    "    //int x = 20;\n" +
                    "    System.out.println(\"Hello World \" + x );\n" +
                    "  }\n" +
                    "}",

            "Soal Kedua:"
                    + "\n" + "public class Main {\n" +
                    "  public static void main(String[] args) {\n" +
                    "    System.out.println(\"Hello World! \");\n" +
                    "    System.out.print(\"Ready to work!\");\n" +
                    "  }\n" +
                    "}",

            "Soal Ketiga:"
                    +"\n"+"public class Main {\n" +
                    "  public static void main(String[] args) {\n" +
                    "    int x = 5;\n" +
                    "    int y = 3;\n" +
                    "    System.out.println(x == y);\n" +
                    "  }\n" +
                    "}",
            "Soal Keempat:"
                    +"\n"+"public class Main {\n" +
                    "  public static void main(String[] args) {\n" +
                    "    System.out.println(\"Yang terbesar adalah \" + Math.min(5, 10));  \n" +
                    "  }\n" +
                    "}",

            "Soal Kelima:"
                    +"\n"+"public class Main {\n" +
                    "  public static void main(String[] args) {\n" +
                    "int day = 0;" +"switch (day) {\n" +
                    "      case -1:\n" +
                    "System.out.println(\"Yesterday\");" +
                    "break;\n" +
                    "      case 1:\n" +
                    "System.out.println(\"Tomorrow\");" +
                    "break;\n" +
                    "    }}}"

    };

    String[] pilihan_jv = new String[]{
            "Error", "Hello World 20", "Hello World ",
            "Hello World ","Hello World\nReady to work!", "Hello World Ready to work",
            "False", "True", "15",
            "Yang terbesar adalah 15", "Yang terbesar adalah 10", "Yang terbesar adalah 5",
            "Null", "Yesterday", "Today"

    };

    String[] jawabanBenar = new String[]{
            "Error",
            "Hello World\nReady to work!",
            "False",
            "Yang terbesar adalah 5",
            "Null"

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java);

        kuis = (TextView) findViewById(R.id.KuisCoba);
        pilihan_jv_ABC = (RadioGroup) findViewById(R.id.pilihan);
        PilihanA = (RadioButton) findViewById(R.id.pilihanA);
        PilihanB = (RadioButton) findViewById(R.id.pilihanB);
        PilihanC = (RadioButton) findViewById(R.id.pilihanC);


        kuis.setText(pertanyaan_jv[number]);
        PilihanA.setText(pilihan_jv[0]);
        PilihanB.setText(pilihan_jv[1]);
        PilihanC.setText(pilihan_jv[2]);

        pilihan_jv_ABC.check(0);
        benar_jv = 0;
        salah_jv = 0;
    }

    public void next(View v) {
        if (PilihanA.isChecked() || PilihanB.isChecked() || PilihanC.isChecked()) {

            RadioButton jawaban_user = (RadioButton) findViewById(pilihan_jv_ABC.getCheckedRadioButtonId());
            String ambilJawabanUser = jawaban_user.getText().toString();
            pilihan_jv_ABC.check(0);
            if (ambilJawabanUser.equalsIgnoreCase(jawabanBenar[number])) benar_jv++;
            else salah_jv++;
            number++;

            if (number < pertanyaan_jv.length) {
                kuis.setText(pertanyaan_jv[(number)]);
                PilihanA.setText(pilihan_jv[(number * 3)]);
                PilihanB.setText(pilihan_jv[(number * 3) + 1]);
                PilihanC.setText(pilihan_jv[(number * 3) + 2]);

            } else {
                hasil_jv = benar_jv * 20;
                Intent selesai_jv = new Intent(JavaActivity.this, HasiljvActivity.class);
                startActivity(selesai_jv);
            }
        } else {
            Toast.makeText(this, "Jawab Terlebih Dahulu", Toast.LENGTH_LONG).show();
        }
    }
}
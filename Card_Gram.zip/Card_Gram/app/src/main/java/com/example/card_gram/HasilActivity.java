package com.example.card_gram;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HasilActivity extends AppCompatActivity {
Button btnHome;
    private Object dari;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil);

        TextView hasil= findViewById(R.id.hasil);
        TextView nilai= findViewById(R.id.nilai);


        hasil.setText("Jawaban Benar: " + DasarActivity.benar +"\nJawaban Salah: " + DasarActivity.salah);
        nilai.setText("-="+ DasarActivity.hasil+"=-");

    }

    public void home(View view) {
        Intent home = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(home);
    }
}
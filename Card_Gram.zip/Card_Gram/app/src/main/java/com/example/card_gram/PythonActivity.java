package com.example.card_gram;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class PythonActivity extends AppCompatActivity {
    TextView kuis;
    RadioGroup pilihan_py_ABC;
    RadioButton PilihanA, PilihanB, PilihanC;
    int number = 0;
    public static int hasil_py, benar_py, salah_py;

    String[] pertanyaan_py = new String[]{
            "Soal Pertama:"
                    + "\n" + "print("+"'Hello'" +")",
            "Soal Kedua:"
                    +"\n" + "x = {\"name\" : \" John\", \"age \" : 36}\n" +
                    "\n" +
                    "print(x)",
            "Soal Ketiga:"
                    + "\n" + "def fungsi(x,y):"
                    + "\n" + "print(x*y)"
                    + "\n" + "fungsi(5,90)",
            "Soal Keempat:"
                    + "\n" + "def fungsi(x):"
                    + "\n" + "if a > 0:"
                    + "\n" + "return 'Positive'"
                    + "\n" + "elif a < 0:"
                    + "\n" + "return 'Negative'"
                    + "\n" + "else:"
                    + "\n" + "return 'Zero'"
                    + "\n" + "print(fungsi(-2^2))",
            "Soal Kelima:"
                    + "\n" + "sampel = [3]"
                    + "\n" + "for y in sampel:"
                    + "\n" + "print(y*y)"

            ,"Soal Keenam:"
            + "\n" +
            "adj = [\"big\"]\n" +
            "fruits = [\"apple\", \"tasty\"]\n" +
            "\n" +
            "for x in adj:\n" +
            "  for y in fruits:\n" +
            "    print(x, y)\n"

            ,"Soal Ketujuh:"
            +"\n" + "x = lambda a: a + 10\n" +
            "print(x(5))"

            ,"Soal Kedelapan:"
            +"\n"+
            "cars = ['Toyota', 'Volvo', 'BMW']\n" +
            "cars[1] = 'Tesla'\n" +
            "print(cars)"

            ,"Soal Kesembilan:"
            +"\n"+
            "sma = [\"IPA\", \"IPS\", \"Bahasa\"]\n" +
            "a= len(sma)\n"

            ,"Soal Kesepuluh:"
            +"\n"+
            "#print(\"Hello Gayus\");\n" +
            "print(\"Hello Della\");\n" +
            "#print(\"Hello Guys\");"

    };

    String[] pilihan_py = new String[]{
            "Helo", "Hello", "Hello World",
            "name: John, age: 36", "John,36", "{'name': 'John', 'age': 36}",
            "5*90", "450", "95",
            "Zero", "Negative", "Positive",
            "9", "3*3", "3"

            ,"big apple \n big tasty", "big apple tasty", "big apple"
            ,"16","15","10"
            ,"'Toyota', 'Volvo', 'BMW'", "'Toyota', 'Tesla', 'BMW'", "'Tesla', 'Volvo', 'BMW'"
            ,"3","MIPA,IPS,Bahasa", "String"
            ,"Hello Gayus", "Hello Della", "Semua ditampilkan"
    };

    String[] jawabanBenar = new String[]{
            "Hello",
            "{'name': 'John', 'age': 36}",
            "450",
            "Positive",
            "9"

            ,"big apple \n big tasty"
            , "15"
            ,"'Toyota', 'Tesla', 'BMW'"
            ,"3"
            ,"Hello Della"

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_python);

        kuis = (TextView) findViewById(R.id.KuisCoba);
        pilihan_py_ABC = (RadioGroup) findViewById(R.id.pilihan);
        PilihanA = (RadioButton) findViewById(R.id.pilihanA);
        PilihanB = (RadioButton) findViewById(R.id.pilihanB);
        PilihanC = (RadioButton) findViewById(R.id.pilihanC);


        kuis.setText(pertanyaan_py[number]);
        PilihanA.setText(pilihan_py[0]);
        PilihanB.setText(pilihan_py[1]);
        PilihanC.setText(pilihan_py[2]);

        pilihan_py_ABC.check(0);
        benar_py = 0;
        salah_py = 0;
    }

    public void next(View v) {
        if (PilihanA.isChecked() || PilihanB.isChecked() || PilihanC.isChecked()) {

            RadioButton jawaban_user = (RadioButton) findViewById(pilihan_py_ABC.getCheckedRadioButtonId());
            String ambilJawabanUser = jawaban_user.getText().toString();
            pilihan_py_ABC.check(0);
            if (ambilJawabanUser.equalsIgnoreCase(jawabanBenar[number])) benar_py++;
            else salah_py++;
            number++;

            if (number < pertanyaan_py.length) {
                kuis.setText(pertanyaan_py[(number)]);
                PilihanA.setText(pilihan_py[(number * 3)]);
                PilihanB.setText(pilihan_py[(number * 3) + 1]);
                PilihanC.setText(pilihan_py[(number * 3) + 2]);

            } else {
                hasil_py = benar_py * 10;
                Intent selesai_py = new Intent(PythonActivity.this, HasilpyActivity.class);
//                selesai_py.putExtra("dari_py",1);

                startActivity(selesai_py);
            }
        } else {
            Toast.makeText(this, "Jawab Terlebih Dahulu", Toast.LENGTH_LONG).show();
        }
    }
}
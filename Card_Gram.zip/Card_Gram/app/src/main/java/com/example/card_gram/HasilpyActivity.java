package com.example.card_gram;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HasilpyActivity extends AppCompatActivity {
    Button btnHome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil);

        TextView hasil= findViewById(R.id.hasil);
        TextView nilai= findViewById(R.id.nilai);

        hasil.setText("Jawaban Benar: " + PythonActivity.benar_py +"\nJawaban Salah: " + PythonActivity.salah_py);
        nilai.setText("-=="+ PythonActivity.hasil_py+"==-");


    }

    public void home(View view) {
        Intent home = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(home);
    }
}